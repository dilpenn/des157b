// initialize AOS
AOS.init();